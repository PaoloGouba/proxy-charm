from scrapers.base_proxy import BaseProxy
