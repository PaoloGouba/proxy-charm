class BaseProxy():
    def __init__(self, url : str, port : str, location : dict, isHttps : bool):
        self.url = url
        self.port = port
        self.location = location
        self.isHttps = isHttps