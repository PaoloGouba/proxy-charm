# monitoring.py
import psutil
import csv
import time
import streamlit as st
import pandas as pd

# Funzione per il monitoraggio e la scrittura dei dati su un file CSV
def monitor_and_write_data():
    with open('dati_monitoraggio.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        while True:
            cpu_percent = psutil.cpu_percent()
            memory_percent = psutil.virtual_memory().percent
            disk_usage = psutil.disk_usage('/').percent
            timestamp = time.time()
            writer.writerow([timestamp, cpu_percent, memory_percent, disk_usage])
            time.sleep(60)  # Esegui il monitoraggio ogni 60 secondi

# Funzione per visualizzare i dati di monitoraggio in una dashboard Streamlit
def create_monitoring_dashboard():
    st.title('Dashboard di Monitoraggio')
    st.write('Dati di Monitoraggio:')
    df = pd.read_csv('dati_monitoraggio.csv')
    st.dataframe(df)

# Esegui il monitoraggio in un thread separato
import threading
monitoring_thread = threading.Thread(target=monitor_and_write_data)
monitoring_thread.daemon = True
monitoring_thread.start()

try :
# Esegui la dashboard Streamlit
    create_monitoring_dashboard()
except :
    pass    
