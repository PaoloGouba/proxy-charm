import requests
from bs4 import BeautifulSoup
from scrapers.base_proxy import BaseProxy
from scrapers.base_scraper import BaseScraper
from scrapers.monitoring import monitor_and_write_data
#from utils.get_proxy_info import *
import subprocess

# Avvia il modulo di monitoraggio come processo separato
subprocess.Popen(["streamlit", "run", "monitoring.py"])

PROXY_URL = [
    'https://free-proxy-list.net/'
]

#get proxies from table in https://free-proxy-list.net/

class FreeProxyList(BaseScraper):
    def __init__(self, use_proxy=False):
        super().__init__(use_proxy)

    def get_free_proxy_list(self, url = PROXY_URL[0]):

        print('Getting Data From freeproxylist.com')

        response = requests.get(url)

        if response.status_code == 200:

            free_proxy_list = []

            page_content = BeautifulSoup(response.content,'lxml')
            text_area = page_content.find('textarea')
            items = text_area.text.split('\n')

            for item in items :
                try :
                    my_proxy = item.split(':')
                    proxy_ip = my_proxy[0]
                    try :
                        proxy_port = my_proxy[1]
                    except :
                        proxy_port = 'N/A' 
                except :
                    pass
                free_proxy = (proxy_ip, proxy_port)
                free_proxy_list.append(free_proxy)    
            return free_proxy_list
        else :
            print("Errore nella richiesta. Codice di stato:", response.status_code)
      
    def create_proxy_charm_list(self,scraped_list : list[tuple]) -> list[BaseProxy]:
        print('Formatting Data in order to analyse')
        proxy_charm_list = []

        for item in scraped_list : 
            url = item[0]
            port = item[1]
            try : 
                proxy_info = self.get_proxy_info(url)
                location = proxy_info["country_name"]
                isHttps = True
            except :
                location = "N/A"    
                isHttps = False
            proxy_charm = BaseProxy(url=url,port=port,location=location,isHttps=isHttps)
            proxy_charm_list.append(proxy_charm)

        return proxy_charm_list     
        
"""my_scraper = FreeProxyList()
my_proxy = my_scraper.get_free_proxy_list()
proxy_charm = my_scraper.create_proxy_charm_list(my_proxy)

print(proxy_charm[0].location)"""