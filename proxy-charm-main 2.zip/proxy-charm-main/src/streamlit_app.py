from scrapers.monitoring import *
from scrapers.free_proxy_list import FreeProxyList
from scrapers.free_proxy_list import BaseProxy

my_proxy = FreeProxyList()


if st.button("Generate List") :
    data =  my_proxy.get_free_proxy_list()
    proxycharme = my_proxy.create_proxy_charm_list(data)
    url = proxycharme[2].url
    st.write(url)
   



